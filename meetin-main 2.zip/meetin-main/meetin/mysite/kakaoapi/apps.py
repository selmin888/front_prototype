from django.apps import AppConfig


class KakaoapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'kakaoapi'
